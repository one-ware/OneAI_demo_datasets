# PepsiCo Lab Potato Chips Quality Control Dataset

This dataset was published by the user Usama Navid on the platform [kaggle](https://www.kaggle.com/datasets/concaption/pepsico-lab-potato-quality-control). For our demo, we resized the images to 512x512 and renamed one of the classes for consistency.
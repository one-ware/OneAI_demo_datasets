# 6 Sided Dice Dataset

This dataset was captured by Roboflow and uploaded on their [website](https://public.roboflow.com/object-detection/dice). For our demo, we restructured the folder structure and transformed the annotations to the format that is currently used by OneWare Studio.